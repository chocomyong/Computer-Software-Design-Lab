package com.example.main_project_two0523;

public class ServerURL {
    public final static String Serverurl = "http://115.22.203.91/";
    public static String getServerurl(){
        return Serverurl;
    }
}
