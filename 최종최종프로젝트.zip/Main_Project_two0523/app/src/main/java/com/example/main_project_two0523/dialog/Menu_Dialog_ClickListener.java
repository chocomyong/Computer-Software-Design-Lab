package com.example.main_project_two0523.dialog;

public interface Menu_Dialog_ClickListener {
    void onPositiveClick();
    void onNegativeClick();

    void onNumberUpClick();
    void onNumberDownClick();


}
