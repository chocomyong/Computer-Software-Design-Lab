package com.example.main_project_two0523;

public class Orders_JSON {
    private String user_ID ;
    private String menu_ID ;
    private String menu_name ;
    private String menu_price ;
    private String menu_num;

    public void setUser_ID(String user_ID) {
        this.user_ID = user_ID;
    }

    public void setMenu_ID(String menu_ID) {
        this.menu_ID = menu_ID;
    }

    public void setMenu_name(String menu_name) {
        this.menu_name = menu_name;
    }

    public void setMenu_price(String menu_price) {
        this.menu_price = menu_price;
    }

    public void setMenu_num(String menu_num) {
        this.menu_num = menu_num;
    }

    public String getUser_ID() {
        return user_ID;
    }

    public String getMenu_ID() {
        return menu_ID;
    }

    public String getMenu_name() {
        return menu_name;
    }

    public String getMenu_price() {
        return menu_price;
    }

    public String getMenu_num() {
        return menu_num;
    }



}
