package com.example.main_project_two0523.dialog;

public interface Rating_Dialog_ClickListener {
    void onPositiveClick();
    void onNegativeClick();
}
