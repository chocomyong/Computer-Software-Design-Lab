package com.example.main_project_five0605.showtable;
public class ListViewItem_ShowTable {
    private String ID ;
    private String occ;


    public void set_ID(String ID) {
        this.ID = ID ;
    }
    public void set_occ(String occ){ this.occ = occ;}


    public String get_ID() {
        return this.ID ;
    }
    public String get_occ(){ return this.occ; }
}
