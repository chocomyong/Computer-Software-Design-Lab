package com.example.main_project_five0605.dialog;

public interface initializeTable {
    void onPositiveClick();
    void onNegativeClick();
}
